function Integrand=TEMP_strip(uvect,vvect,x,y,z,freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss)

Nlayers=length(h); %# of layers
Nu=length(uvect);
Nv=length(vvect);

%% Extract Anisotropic Ratios
phi_xx=kx./kz;
phi_yy=ky./kz;
phi_xy=kxy./kz;
phi_xz=kxz./kz;
phi_yz=kyz./kz;

%% 
for n =1:Nlayers-1
    lambda1 = 1i*C(n)*2*pi*freq/kz(n)*ones(Nu,Nv)+4*pi^2*(phi_xx(n)*(uvect.^2)*ones(1,Nv)+2*phi_xy(n)*(uvect*vvect)+phi_yy(n)*ones(Nu,1)*(vvect.^2));
    lambda2 = 4*1i*pi*(phi_xz(n)*uvect*ones(1,Nv)+phi_yz(n)*ones(Nu,1)*vvect);
    uplus = 1/2*(-lambda2+sqrt(lambda2.^2+4*lambda1));
    uminus = 1/2*(-lambda2-sqrt(lambda2.^2+4*lambda1));
    phi_plus = uplus*h(n);
    phi_minus = uminus*h(n);
    phi_plus(real(phi_plus)>200) = 200 + 1i*imag(phi_plus(real(phi_plus)>200)); %Prevent numerical errors - if real(phi) is to large, exp(phi) will blow up.
    phi_minus(real(phi_minus)>200) = 200 + 1i*imag(phi_minus(real(phi_minus)>200));
    phi_plus(real(phi_plus)<-200) = -200 + 1i*imag(phi_plus(real(phi_plus)<-200)); %Prevent numerical errors - if real(phi) is to large, exp(phi) will blow up.
    phi_minus(real(phi_minus)<-200) = -200 + 1i*imag(phi_minus(real(phi_minus)<-200));    
    exp_plus = exp(phi_plus);
    exp_minus = exp(phi_minus);

    M11 = -uminus./(uplus-uminus);      M12 = -1/kz(n)./(uplus-uminus);
    M21 = uplus./(uplus-uminus);        M22 = 1/kz(n)./(uplus-uminus);
    N11 = exp_plus;                     N12 = exp_minus;
    N21 = -kz(n)*uplus.*exp_plus;       N22 = -kz(n)*uminus.*exp_minus;
    
    if n==1
        T11 = N11.*M11+N12.*M21;            T12 = N11.*M12+N12.*M22;
        T21 = N21.*M11+N22.*M21;            T22 = N21.*M12+N22.*M22;
    else
        NM11 = N11.*M11+N12.*M21;           NM12 = N11.*M12+N12.*M22;
        NM21 = N21.*M11+N22.*M21;           NM22 = N21.*M12+N22.*M22;        
        Tn11 = NM11.*T11+NM12.*T21;         Tn12 = NM11.*T12+NM12.*T22;
        Tn21 = NM21.*T11+NM22.*T21;         Tn22 = NM21.*T12+NM22.*T22; 
        T11 = Tn11;                         T12 = Tn12;
        T21 = Tn21;                         T22 = Tn22;         
    end

end

n=Nlayers;
    lambda1 = 1i*C(n)*2*pi*freq/kz(n)*ones(Nu,Nv)+4*pi^2*(phi_xx(n)*(uvect.^2)*ones(1,Nv)+2*phi_xy(n)*(uvect*vvect)+phi_yy(n)*ones(Nu,1)*(vvect.^2));
    lambda2 = 4*1i*pi*(phi_xz(n)*uvect*ones(1,Nv)+phi_yz(n)*ones(Nu,1)*vvect);
    uplus = 1/2*(-lambda2+sqrt(lambda2.^2+4*lambda1));
    NM11 = 1;                   NM12 = -1/kz(n)./uplus;
    NM21 = -kz(n)*uplus;        NM22 = 1;
    Tn11 = NM11.*T11+NM12.*T21;         Tn12 = NM11.*T12+NM12.*T22;
    Tn21 = NM21.*T11+NM22.*T21;         Tn22 = NM21.*T12+NM22.*T22; 
    T11 = Tn11;                         T12 = Tn12;
    T21 = Tn21;                         T22 = Tn22; 
        
G=-T22./(T21-hloss*T22); %The layer G(k)
%% 
if z>0
    for n =1:Nlayers
        lambda1 = 1i*C(n)*2*pi*freq/kz(n)*ones(Nu,Nv)+4*pi^2*(phi_xx(n)*(uvect.^2)*ones(1,Nv)+2*phi_xy(n)*(uvect*vvect)+phi_yy(n)*ones(Nu,1)*(vvect.^2));
        lambda2 = 4*1i*pi*(phi_xz(n)*uvect*ones(1,Nv)+phi_yz(n)*ones(Nu,1)*vvect);
        uplus = 1/2*(-lambda2+sqrt(lambda2.^2+4*lambda1));
        uminus = 1/2*(-lambda2-sqrt(lambda2.^2+4*lambda1));
        if z>h(n)
            phi_plus = uplus*h(n);
            phi_minus = uminus*h(n);
        else
            phi_plus = uplus*z;
            phi_minus = uminus*z;  
        end
        phi_plus(real(phi_plus)>300) = 300 + 1i*imag(phi_plus(real(phi_plus)>300)); %Prevent numerical errors - if real(phi) is to large, exp(phi) will blow up.
        phi_minus(real(phi_minus)>300) = 300 + 1i*imag(phi_minus(real(phi_minus)>300));
        phi_plus(real(phi_plus)<-300) = -300 + 1i*imag(phi_plus(real(phi_plus)<-300)); %Prevent numerical errors - if real(phi) is to large, exp(phi) will blow up.
        phi_minus(real(phi_minus)<-300) = -300 + 1i*imag(phi_minus(real(phi_minus)<-300));    
        exp_plus = exp(phi_plus);
        exp_minus = exp(phi_minus);

        M11 = -uminus./(uplus-uminus);      M12 = -1/kz(n)./(uplus-uminus);
        M21 = uplus./(uplus-uminus);        M22 = 1/kz(n)./(uplus-uminus);
        N11 = exp_plus;                     N12 = exp_minus;
        N21 = -kz(n)*uplus.*exp_plus;       N22 = -kz(n)*uminus.*exp_minus;

        if n==1
            T11 = N11.*M11+N12.*M21;            T12 = N11.*M12+N12.*M22;
            T21 = N21.*M11+N22.*M21;            T22 = N21.*M12+N22.*M22;
        else
            NM11 = N11.*M11+N12.*M21;           NM12 = N11.*M12+N12.*M22;
            NM21 = N21.*M11+N22.*M21;           NM22 = N21.*M12+N22.*M22;        
            Tn11 = NM11.*T11+NM12.*T21;         Tn12 = NM11.*T12+NM12.*T22;
            Tn21 = NM21.*T11+NM22.*T21;         Tn22 = NM21.*T12+NM22.*T22; 
            T11 = Tn11;                         T12 = Tn12;
            T21 = Tn21;                         T22 = Tn22;         
        end
        if z>h(n)
            z=z-h(n);
        else
            break
        end
    end
    G1=(T11-hloss*T12).*G+T12;
    G=G1;
end
%% 
%Kernal=A_pump*exp(-0.5*pi^2*(r_x^2*(uvect.*uvect)*ones(1,length(vvect))+r_y^2*ones(length(uvect),1)*(vvect.*vvect))).*exp(1i*2*pi*(uvect*ones(1,length(vvect))*x+ones(length(uvect),1)*vvect*y)); %The rest of the integrand
Kernal=A_pump*sinc(r_x*uvect*ones(1,length(vvect))).*sinc(r_y*ones(length(uvect),1)*vvect).*exp(1i*2*pi*(uvect*ones(1,length(vvect))*x+ones(length(uvect),1)*vvect*y)); %The rest of the integrand

Integrand=G.*Kernal;
end        
