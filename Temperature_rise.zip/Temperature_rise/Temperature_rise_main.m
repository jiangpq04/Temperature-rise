tic %Start the timer
addpath(genpath('../Temperature_rise'))
clc
clear all
%% -------------TYPE THERMAL SYSTEM PARAMTERS HERE--------------
kx=[160 160];   %[W/m-K]
ky=[160 160];   %[W/m-K]
kz=[160 160];   %[W/m-K]
kxy=[0   0  ];  %[W/m-K]
kxz=[0   0  ];  %[W/m-K] 
kyz=[0   0  ];  %[W/m-K]
C=[1 1]*1e6;    %[J/m^3-K]
h=[100  5e5]*1e-9; %[m], layer thickness
r_x=20e-6;  %[m], =L for strip heating
r_y=5e-6;   %[m], =b for strip heating
freq=10000;   %[Hz], heating frequency

hloss=0;    %[W/m2K], heat loss coefficient
A_pump=50e-3; %[W],laser power
laser_heating=1;    %flag(1=laser heating; others=strip heating)

%% -----------DEFINE GRIDS-------------------------------------------------
% Parameters (umax, NN, grid-size) should be checked to make sure they do
% not affect the results
umax=5/min(r_x,r_y);       
NN=500;
grid_size=umax*logspace(log10(1e-13),log10(0.5),NN);
uvect=zeros(1,NN);
uvect(1)=grid_size(1)/2;
for i=2:NN
    uvect(i)=uvect(i-1)+(grid_size(i-1)+grid_size(i))/2;
end
vvect=sort([-uvect uvect]);
uvect=vvect';
vweights=abs(sort([-grid_size grid_size]));
uweights=vweights';

%% --------Calculate Temperature profile on the surface (z=0)--------------
CalcTxy=1;  
if CalcTxy==1
    x=sort([-1*logspace(log10(0.00001e-6),log10(3*r_x),100) 0 logspace(log10(0.00001e-6),log10(3*r_x),100)])'; 
    y=sort([-1*logspace(log10(0.00001e-6),log10(3*r_y),100) 0 logspace(log10(0.00001e-6),log10(3*r_y),100)]); 
    theta_xy=zeros(length(x),length(y));

    for i=1:length(x)
        for j=1:length(y)
            if laser_heating==1
                DeltaTmat=TEMP_laser(uvect,vvect,x(i),y(j),0,freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            else
                DeltaTmat=TEMP_strip(uvect,vvect,x(i),y(j),0,freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            end
            theta_xy(i,j)=sum(sum((uweights*vweights).*DeltaTmat));   
        end
    end
    Re_thetaxy=real(theta_xy);
    Im_thetaxy=imag(theta_xy);
    Amp_thetaxy=sqrt(Re_thetaxy.^2+Im_thetaxy.^2);

    figure(1)
    surf(x,y,Amp_thetaxy,'EdgeColor','none','FaceColor','interp');set(gca,'FontSize',16)
    xlabel('x(m)','FontSize',16,'FontWeight','Bold');
    ylabel('y(m)','FontSize',16,'FontWeight','Bold');
    axis([min(x) max(x) min(y) max(y)]);
    colormap(jet(500));
    daspect([1 1 1])
    
end
%% -------Calculate Temperature profile on the xz cross-section (y=0)------
CalcTxz=0;
if CalcTxz==1
    x=sort([-1*logspace(log10(0.00001e-6),log10(3*r_x),100) 0 logspace(log10(0.00001e-6),log10(3*r_x),100)]); 
    z=sort([linspace(0,h(1),10) logspace(log10(h(1)+1e-9),log10(h(1)+10e-6),100)]); 
    theta_xz=zeros(length(x),length(z));

    for i=1:length(x)
        for j=1:length(z)
            if laser_heating==1
                DeltaTmat=TEMP_laser(uvect,vvect,x(i),0,z(j),freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            else
                DeltaTmat=TEMP_strip(uvect,vvect,x(i),0,z(j),freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            end
            theta_xz(i,j)=sum(sum((uweights*vweights).*DeltaTmat));   
        end
    end
    Re_thetaxz=real(theta_xz);
    Im_thetaxz=imag(theta_xz);
    Amp_thetaxz=sqrt(Re_thetaxz.^2+Im_thetaxz.^2);

    figure(2)
    [Z,X]=meshgrid(z,x);
    surf(X,Z,Amp_thetaxz,'EdgeColor','none','FaceColor','interp');set(gca,'FontSize',16)
    xlabel('x(m)','FontSize',16,'FontWeight','Bold');
    ylabel('z(m)','FontSize',16,'FontWeight','Bold');
    axis([min(x) max(x) min(z) max(z)]);
    colormap(jet(500));
    daspect([1 1 1])
    
end
%% -------Calculate Temperature profile on the yz cross-section (x=0)------
CalcTyz=0;
if CalcTyz==1
    y=sort([-1*logspace(log10(0.00001e-6),log10(3*r_y),100) 0 logspace(log10(0.00001e-6),log10(3*r_y),100)]); 
    z=sort([linspace(0,h(1),10) logspace(log10(h(1)+1e-9),log10(h(1)+10e-6),100)]); 
    theta_yz=zeros(length(y),length(z));

    for i=1:length(y)
        for j=1:length(z)
            if laser_heating==1
                DeltaTmat=TEMP_laser(uvect,vvect,0,y(i),z(j),freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            else
                DeltaTmat=TEMP_strip(uvect,vvect,0,y(i),z(j),freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            end
            theta_yz(i,j)=sum(sum((uweights*vweights).*DeltaTmat));   
        end
    end
    Re_thetayz=real(theta_yz);
    Im_thetayz=imag(theta_yz);
    Amp_thetayz=sqrt(Re_thetayz.^2+Im_thetayz.^2);

    figure(3)
    [Z,Y]=meshgrid(z,y);
    surf(Y,Z,Amp_thetayz,'EdgeColor','none','FaceColor','interp');set(gca,'FontSize',16)
    xlabel('y(m)','FontSize',16,'FontWeight','Bold');
    ylabel('z(m)','FontSize',16,'FontWeight','Bold');
    axis([min(y) max(y) min(z) max(z)]);
    colormap(jet(500));
    daspect([1 1 1])
end
%% -------Calculate Temperature profile along z direction (x=y=0)----------
CalcTz=0;
if CalcTz==1
    z=sort([linspace(0,h(1),10) logspace(log10(h(1)+1e-9),log10(h(1)+4e-4),100)]); 
    theta_z=zeros(1,length(z));

        for j=1:length(z)
            if laser_heating==1
                DeltaTmat=TEMP_laser(uvect,vvect,0,0,z(j),freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            else
                DeltaTmat=TEMP_strip(uvect,vvect,0,0,z(j),freq,kx,ky,kz,kxy,kxz,kyz,C,h,r_x,r_y,A_pump,hloss);
            end
            theta_z(j)=sum(sum((uweights*vweights).*DeltaTmat));   
        end

    Re_thetaz=real(theta_z);
    Im_thetaz=imag(theta_z);
    Amp_thetaz=sqrt(Re_thetaz.^2+Im_thetaz.^2);

    figure(4)
    plot(z,Amp_thetaz);set(gca,'FontSize',16)
    xlabel('z(m)','FontSize',16,'FontWeight','Bold');
    ylabel('\theta (K)','FontSize',16,'FontWeight','Bold');
    dlmwrite('Tprofile.txt',[z'*1e9 Amp_thetaz'],'delimiter','\t','precision',8);
    movefile('Tprofile.txt','Outputs')
    
    %--Analytical T profile
    n=2;    %index of the layer of semi-infinite 
    F0=2*A_pump/pi/r_x/r_y;
    alpha=kz(n)/C(n);
    t=1;
    Tprofile=2*F0/kz(n)*(sqrt(alpha*t/pi)*exp(-z.^2/4/alpha/t)-z/2.*erfc(z/2/sqrt(alpha*t)));
    figure (5)
    plot(z,Amp_thetaz,z,Tprofile);set(gca,'FontSize',16)
    %------delta(heat flux reduction factor)-------------------------
  %  n=length(h);
   % G=kz(n-1)/h(n-1);
  %  Expmat = exp(-pi^2/2*(r_x^2*uvect.^2*ones(1,length(vvect))+r_y^2*(ones(length(uvect),1)*vvect.^2))); % (u*v)
  %  u1plus=2*pi*sqrt(kx(n-2)*uvect.^2*ones(1,length(vvect))+ky(n-2)*(ones(length(uvect),1)*vvect.^2))/sqrt(kz(n-2));
  %  u2plus=2*pi*sqrt(kx(n)*uvect.^2*ones(1,length(vvect))+ky(n)*(ones(length(uvect),1)*vvect.^2))/sqrt(kz(n));
  %  Polymat = pi*r_x*r_y/2./((kz(n-2)*u1plus/G+kz(n-2)/kz(n)*u1plus./u2plus).*sinh(u1plus*h(n-2))+cosh(u1plus*h(n-2)));
  %  delta = sum(sum((uweights*vweights).*Expmat.*Polymat))
    %------theta_ratio_xi-------------------------------------
   % alpha=sqrt(ky(n)/kx(n));
  %  beta=r_y/r_x;
  %  Polymat2 = r_x/sqrt(2*pi)*sqrt(alpha*beta)./sqrt((uvect.^2*ones(1,length(vvect)))+alpha^2*(ones(length(uvect),1)*vvect.^2));
  %  theta_ratio = sum(sum((uweights*vweights).*Expmat.*Polymat2))  
end

%% ----------------------------------------------------
toc
fprintf('Program Completed\n')
beep
beep
beep